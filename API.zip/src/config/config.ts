export default {
    jwtSecret: "@QEGTUI"
};